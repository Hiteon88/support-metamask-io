# README

**WARNING:** These Move examples have NOT been audited. If using it in a production system, proceed at your own risk.
Particular care should be taken with Move examples that contain complex cryptographic code (e.g., `drand`, `veiled_coin`).

## Before compiling and testing

Replace the _ in Move.toml with your Aptos wallet address.
